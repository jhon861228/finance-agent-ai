import { DynamoDBClient, UpdateItemCommand, PutItemCommand, DeleteItemCommand, QueryCommand } from '@aws-sdk/client-dynamodb';
import { marshall, unmarshall } from '@aws-sdk/util-dynamodb';
import { DomainEvent, EventType, ExpenseAddedEvent, GroupCreatedEvent, MemberAddedEvent, SettlementRecordedEvent, PersonalExpenseRecordedEvent, UserCreatedEvent, PersonalExpenseDeletedEvent, PersonalAccountClearedEvent } from '../events/Types';

const client = new DynamoDBClient({
    region: process.env.AWS_REGION || 'us-east-1',
    endpoint: process.env.DYNAMODB_ENDPOINT || undefined,
    credentials: process.env.DYNAMODB_ENDPOINT ? {
        accessKeyId: 'fake',
        secretAccessKey: 'fake'
    } : undefined
});
const TABLE_NAME = process.env.READ_MODELS_TABLE || 'finance-agent-read-models';

export class Projector {
    async handle(event: DomainEvent) {
        try {
            switch (event.type) {
                case EventType.GROUP_CREATED:
                    await this.projectGroupCreated(event as GroupCreatedEvent);
                    break;
                case EventType.MEMBER_ADDED:
                    await this.projectMemberAdded(event as MemberAddedEvent);
                    break;
                case EventType.EXPENSE_ADDED:
                    await this.projectExpenseAdded(event as ExpenseAddedEvent);
                    break;
                case EventType.PERSONAL_EXPENSE_RECORDED:
                    await this.projectPersonalExpenseRecorded(event as PersonalExpenseRecordedEvent);
                    break;
                case EventType.USER_CREATED:
                    await this.projectUserCreated(event as UserCreatedEvent);
                    break;
                case EventType.PERSONAL_EXPENSE_DELETED:
                    await this.projectPersonalExpenseDeleted(event as PersonalExpenseDeletedEvent);
                    break;
                case EventType.PERSONAL_ACCOUNT_CLEARED:
                    await this.projectPersonalAccountCleared(event as PersonalAccountClearedEvent);
                    break;
            }
        } catch (error) {
            console.error('Error projecting event:', error);
            throw error;
        }
    }

    private async projectGroupCreated(event: GroupCreatedEvent) {
        const params = {
            TableName: TABLE_NAME,
            Key: marshall({ pk: `GROUP#${event.aggregateId}`, sk: 'METADATA' }),
            UpdateExpression: 'SET #name = :name, createdBy = :createdBy, createdAt = :createdAt',
            ExpressionAttributeNames: { '#name': 'name' },
            ExpressionAttributeValues: marshall({
                ':name': event.payload.name,
                ':createdBy': event.payload.createdBy,
                ':createdAt': event.timestamp,
            }),
        };
        await client.send(new UpdateItemCommand(params));
    }

    private async projectMemberAdded(event: MemberAddedEvent) {
        const params = {
            TableName: TABLE_NAME,
            Key: marshall({ pk: `GROUP#${event.aggregateId}`, sk: `MEMBER#${event.payload.userId}` }),
            UpdateExpression: 'SET #name = :name, telegramId = :tid',
            ExpressionAttributeNames: { '#name': 'name' },
            ExpressionAttributeValues: marshall({
                ':name': event.payload.name,
                ':tid': event.payload.telegramId || null,
            }),
        };
        await client.send(new UpdateItemCommand(params));
    }

    private async projectExpenseAdded(event: ExpenseAddedEvent) {
        // 1. Store the expense item for listing
        const expenseParams = {
            TableName: TABLE_NAME,
            Key: marshall({ pk: `GROUP#${event.aggregateId}`, sk: `EXPENSE#${event.payload.expenseId}` }),
            UpdateExpression: 'SET amount = :amount, description = :desc, payerId = :payer, #ts = :ts',
            ExpressionAttributeNames: { '#ts': 'timestamp' },
            ExpressionAttributeValues: marshall({
                ':amount': event.payload.amount,
                ':desc': event.payload.description,
                ':payer': event.payload.payerId,
                ':ts': event.timestamp
            })
        };
        await client.send(new UpdateItemCommand(expenseParams));

        // 2. Update balances (Simplified manual projection, ignoring splits for now)
        // For a real app, we'd read current balances, calculate new ones, and atomic write.
        // Here just incrementing the Payer's "paid" amount for simplicity in this artifact.
        const balanceParams = {
            TableName: TABLE_NAME,
            Key: marshall({ pk: `GROUP#${event.aggregateId}`, sk: `BALANCE#${event.payload.payerId}` }),
            UpdateExpression: 'ADD paidAmount :amount',
            ExpressionAttributeValues: marshall({
                ':amount': event.payload.amount
            })
        };
        await client.send(new UpdateItemCommand(balanceParams));
    }

    private async projectSettlementRecorded(event: SettlementRecordedEvent) {
        // 1. Store Settlement History
        const historyParams = {
            TableName: TABLE_NAME,
            Item: marshall({
                pk: `GROUP#${event.aggregateId}`,
                sk: `SETTLEMENT#${event.timestamp}`,
                transfers: event.payload.transfers,
                timestamp: event.timestamp
            })
        };
        await client.send(new PutItemCommand(historyParams));

        // 2. Update Balances (reverse of expense)
        // From (Payer) -> their "paidAmount" INCREASES (they contributed cash to settle)
        // To (Payee) -> their "paidAmount" DECREASES (they got money back, so their net contribution drops)
        for (const transfer of event.payload.transfers) {
            // Credit Payer
            await client.send(new UpdateItemCommand({
                TableName: TABLE_NAME,
                Key: marshall({ pk: `GROUP#${event.aggregateId}`, sk: `BALANCE#${transfer.from}` }),
                UpdateExpression: 'ADD paidAmount :amount',
                ExpressionAttributeValues: marshall({ ':amount': transfer.amount })
            }));

            // Debit Payee
            await client.send(new UpdateItemCommand({
                TableName: TABLE_NAME,
                Key: marshall({ pk: `GROUP#${event.aggregateId}`, sk: `BALANCE#${transfer.to}` }),
                UpdateExpression: 'ADD paidAmount :amount',
                ExpressionAttributeValues: marshall({ ':amount': -transfer.amount })
            }));
        }
    }

    private async projectPersonalExpenseRecorded(event: PersonalExpenseRecordedEvent) {
        const params = {
            TableName: TABLE_NAME,
            Item: marshall({
                pk: `USER#${event.aggregateId}`,
                sk: `EXPENSE#${event.payload.expenseId}`,
                amount: event.payload.amount,
                category: event.payload.category,
                description: event.payload.description,
                timestamp: event.timestamp
            })
        };
        await client.send(new PutItemCommand(params));
    }

    private async projectPersonalExpenseDeleted(event: PersonalExpenseDeletedEvent) {
        // Find exact SK first to handle both formats
        const queryParams = {
            TableName: TABLE_NAME,
            KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
            ExpressionAttributeValues: {
                ':pk': { S: `USER#${event.aggregateId}` },
                ':prefix': { S: 'EXPENSE#' }
            }
        };

        const { Items } = await client.send(new QueryCommand(queryParams));
        if (!Items) return;

        const targetItem = Items.find(item => {
            const doc = unmarshall(item);
            return (doc.sk as string).includes(event.payload.expenseId);
        });

        if (targetItem) {
            const sk = unmarshall(targetItem).sk;
            await client.send(new DeleteItemCommand({
                TableName: TABLE_NAME,
                Key: marshall({ pk: `USER#${event.aggregateId}`, sk })
            }));
        }
    }

    private async projectPersonalAccountCleared(event: PersonalAccountClearedEvent) {
        const queryParams = {
            TableName: TABLE_NAME,
            KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
            ExpressionAttributeValues: {
                ':pk': { S: `USER#${event.aggregateId}` },
                ':prefix': { S: 'EXPENSE#' }
            }
        };

        const { Items } = await client.send(new QueryCommand(queryParams));
        if (!Items) return;

        for (const item of Items) {
            const sk = unmarshall(item).sk;
            await client.send(new DeleteItemCommand({
                TableName: TABLE_NAME,
                Key: marshall({ pk: `USER#${event.aggregateId}`, sk })
            }));
        }
    }

    private async projectUserCreated(event: UserCreatedEvent) {
        const params = {
            TableName: TABLE_NAME,
            Key: marshall({ pk: `USER#${event.aggregateId}`, sk: 'METADATA' }),
            UpdateExpression: 'SET #name = :name, telegramId = :tid, createdAt = :ts',
            ExpressionAttributeNames: { '#name': 'name' },
            ExpressionAttributeValues: marshall({
                ':name': event.payload.name,
                ':tid': event.payload.telegramId || null,
                ':ts': event.timestamp
            })
        };
        await client.send(new UpdateItemCommand(params));
    }
}
