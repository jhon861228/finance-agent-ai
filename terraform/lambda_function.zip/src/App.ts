import dotenv from 'dotenv';
dotenv.config();

import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import { CommandProcessor, Command } from './core/CommandProcessor';
import { QueryService } from './core/QueryService';
import { v4 as uuidv4 } from 'uuid';

const app = express();
console.log('Environment Debug:');
console.log('DYNAMODB_ENDPOINT:', process.env.DYNAMODB_ENDPOINT);
console.log('AWS_REGION:', process.env.AWS_REGION);
app.use(cors());
app.use(bodyParser.json());

// Routes using the same logic as Lambda
app.post('/api/commands', async (req: Request, res: Response) => {
    try {
        const command = req.body as Command;
        const result = await CommandProcessor.process(command);
        res.json(result);
    } catch (error: any) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/groups/:groupId', async (req: Request, res: Response) => {
    try {
        const result = await QueryService.getGroupDetails(req.params.groupId as string);
        if (!result) {
            res.status(404).json({ error: 'Group not found' });
        } else {
            res.json(result);
        }
    } catch (error: any) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/groups', async (req: Request, res: Response) => {
    try {
        const result = await QueryService.listGroups();
        res.json(result);
    } catch (error: any) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/groups/:groupId/members', async (req: Request, res: Response) => {
    try {
        const result = await QueryService.getGroupMembers(req.params.groupId as string);
        res.json(result);
    } catch (error: any) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

// Personal Expenses
app.post('/api/personal/expenses/:userId', async (req: Request, res: Response) => {
    try {
        // userId is now in the URI, not the body
        const userId = req.params.userId;
        const payload = { ...req.body, userId };

        const command = {
            commandId: uuidv4(),
            type: 'RecordPersonalExpense',
            payload: payload
        } as Command;

        const result = await CommandProcessor.process(command);
        res.json(result);
    } catch (error: any) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/personal/expenses/:userId', async (req: Request, res: Response) => {
    try {
        const result = await QueryService.getPersonalExpenses(req.params.userId as string);
        res.json(result);
    } catch (error: any) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

app.delete('/api/personal/expenses/:userId/:expenseId', async (req: Request, res: Response) => {
    try {
        const command = {
            commandId: uuidv4(),
            type: 'DeletePersonalExpense',
            payload: {
                userId: req.params.userId,
                expenseId: req.params.expenseId
            }
        } as Command;

        const result = await CommandProcessor.process(command);
        res.json(result);
    } catch (error: any) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

app.delete('/api/personal/expenses/:userId', async (req: Request, res: Response) => {
    try {
        const command = {
            commandId: uuidv4(),
            type: 'ClearPersonalExpenses',
            payload: {
                userId: req.params.userId
            }
        } as Command;

        const result = await CommandProcessor.process(command);
        res.json(result);
    } catch (error: any) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

// User Management
app.get('/api/users', async (req: Request, res: Response) => {
    try {
        console.log('Users Route:', req.body);
        const result = await QueryService.listUsers();
        res.json(result);
    } catch (error: any) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/users', async (req: Request, res: Response) => {
    try {
        const command = {
            commandId: uuidv4(),
            type: 'CreateUser',
            payload: req.body
        } as Command;

        const result = await CommandProcessor.process(command);
        res.json(result);
    } catch (error: any) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

// Telegram Webhook
app.post('/api/telegram', async (req: Request, res: Response) => {
    try {
        console.log('Telegram Route:', req.body);
        // We import the handler logic. 
        // Note: For local use, we might want to bypass Lambda client dependency in the handler.
        const { TelegramHandler } = await import('./handlers/TelegramHandler');
        await TelegramHandler.handle(req.body);
        res.status(200).send('OK');
    } catch (error: any) {
        console.error('Telegram Route Error:', error);
        res.status(500).json({ error: error.message });
    }
});

app.get('/health', (req, res) => {
    res.json({ status: 'ok' });
});

export default app;
